const express = require("express");

const app = express();

require("dotenv").config();
app.use(express.json());
app.use(express.urlencoded({extended :true}));

// Connection

const {DbConnection} = require("./Config/Db")





const {getAllRoles ,createRole } = require(".//Controller/insert")



app.route("/role").get(getAllRoles).post(createRole);
app.listen(process.env.PORT,function(){
    console.log(`Server is running on the PORT ${process.env.PORT}`)
    DbConnection();
})