
const {Roles} = require("../Model/userRoles");  
    async function createRole(req,res){
        const {RoleName,status} = req.body;
    
        const roleNameCheck = /^[a-zA-Z]+(?: [a-zA-Z]+)*$/;
    
        if(roleNameCheck.test(RoleName)){
    
        const exists = await Roles.find({RoleName:RoleName.toLowerCase()})
    
    
        if (exists.length > 0 )   return res.send({"error":"role is already exist"})
        
            const newRole = await Roles.create(
    
            {
                RoleName:RoleName.toLowerCase(),
                status:status
            }
        )
    
    
        return res.send({"data":req.body})
    }else{
        return res.send({"error":"role name contain only characterz"})
    }
    
    
    
    
}

// METHOD -- GET 
// API http://localhost:5000/role
//des:  get all user roles
async function getAllRoles(req,res){
        
        const allRoles = await Roles.find();
        return res.send({"data":allRoles})
    }

module.exports = {getAllRoles ,createRole }
